<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Headless\Model\Indexer\Fulltext\Action;

use Magento\CatalogSearch\Model\Indexer\Fulltext;
use Magento\CatalogSearch\Model\Indexer;
use Magento\CatalogSearch\Model\Indexer\Fulltext\Action;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\ResourceConnection;

class Full extends \Magento\CatalogSearch\Model\Indexer\Fulltext\Action\Full
{
    /**
     * @var DataProvider
     */
    private $dataProvider;
    
    protected $_productloader;  
    
    public function __construct(
        ResourceConnection $resource,
        \Magento\Catalog\Model\Product\Type $catalogProductType,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Framework\Search\Request\Config $searchRequestConfig,
        \Magento\Catalog\Model\Product\Attribute\Source\Status $catalogProductStatus,
        \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $prodAttributeCollectionFactory,
        \Magento\CatalogSearch\Model\ResourceModel\EngineProvider $engineProvider,
        \Magento\CatalogSearch\Model\Indexer\IndexerHandlerFactory $indexHandlerFactory,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime $dateTime,
        \Magento\Framework\Locale\ResolverInterface $localeResolver,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\CatalogSearch\Model\ResourceModel\Fulltext $fulltextResource,
        \Magento\Framework\Search\Request\DimensionFactory $dimensionFactory,
        \Magento\Framework\Indexer\ConfigInterface $indexerConfig,
        \Magento\CatalogSearch\Model\Indexer\Fulltext\Action\IndexIteratorFactory $indexIteratorFactory,
        \Magento\Framework\EntityManager\MetadataPool $metadataPool = null,
        \Magento\CatalogSearch\Model\Indexer\Fulltext\Action\DataProvider $dataProvider = null,
        $batchSize = 500,
        \Magento\Catalog\Model\ProductFactory $_productloader
    ) {
        $this->resource = $resource;
        $this->connection = $resource->getConnection();
        $this->catalogProductType = $catalogProductType;
        $this->eavConfig = $eavConfig;
        $this->searchRequestConfig = $searchRequestConfig;
        $this->catalogProductStatus = $catalogProductStatus;
        $this->productAttributeCollectionFactory = $prodAttributeCollectionFactory;
        $this->eventManager = $eventManager;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->engine = $engineProvider->get();
        $configData = $indexerConfig->getIndexer(Fulltext::INDEXER_ID);
        $this->indexHandler = $indexHandlerFactory->create(['data' => $configData]);
        $this->dateTime = $dateTime;
        $this->localeResolver = $localeResolver;
        $this->localeDate = $localeDate;
        $this->fulltextResource = $fulltextResource;
        $this->dimensionFactory = $dimensionFactory;
        $this->iteratorFactory = $indexIteratorFactory;
        $this->metadataPool = $metadataPool ?: ObjectManager::getInstance()
            ->get(\Magento\Framework\EntityManager\MetadataPool::class);
        $this->dataProvider = $dataProvider ?: ObjectManager::getInstance()->get(\Magento\CatalogSearch\Model\Indexer\Fulltext\Action\DataProvider::class);
        $this->batchSize = $batchSize;
        
        parent::__construct($resource, $catalogProductType, $eavConfig, $searchRequestConfig, $catalogProductStatus, $prodAttributeCollectionFactory, $engineProvider,
        $indexHandlerFactory, $eventManager, $scopeConfig, $storeManager, $dateTime, $localeResolver, $localeDate, $fulltextResource, $dimensionFactory,
        $indexerConfig, $indexIteratorFactory, $metadataPool, $dataProvider, $batchSize);
        
        //custom kharvi headless
        $this->_productloader = $_productloader;
    }
    /**
     * Regenerate search index for specific store
     *
     * To be suitable for indexation product must meet set of requirements:
     * - to be visible on frontend
     * - to be enabled
     * - in case product is composite at least one sub product must be enabled
     *
     * @param int $storeId Store View Id
     * @param int[] $productIds Product Entity Id
     * @return \Generator
     */
    public function rebuildStoreIndex($storeId, $productIds = null)
    {
        if ($productIds !== null) {
            $productIds = array_unique($productIds);
        }
        
        //custom kharvi headless
        $attributes = $this->scopeConfig->getValue('kharvi_headless/general/attributes');
        $flat_enabled = $this->scopeConfig->getValue('catalog/frontend/flat_catalog_product');
        
        // prepare searchable attributes
        $staticFields = [];
        foreach ($this->getSearchableAttributes('static') as $attribute) {
            $staticFields[] = $attribute->getAttributeCode();
        }

        $dynamicFields = [
            'int' => array_keys($this->dataProvider->getSearchableAttributes('int')),
            'varchar' => array_keys($this->dataProvider->getSearchableAttributes('varchar')),
            'text' => array_keys($this->dataProvider->getSearchableAttributes('text')),
            'decimal' => array_keys($this->dataProvider->getSearchableAttributes('decimal')),
            'datetime' => array_keys($this->dataProvider->getSearchableAttributes('datetime')),
        ];

        $offset = 0;$lastProductId = 0;
        $products = $this->dataProvider
            ->getSearchableProducts($storeId, $staticFields, $productIds, $lastProductId, $this->batchSize);
        while (count($products) > 0) {
            $productsIds = array_column($products, 'entity_id');
            $relatedProducts = $this->getRelatedProducts($products);
            $productsIds = array_merge($productsIds, array_values($relatedProducts));

            $productsAttributes = $this->dataProvider->getProductAttributes($storeId, $productsIds, $dynamicFields);

            foreach ($products as $productData) {
                //$lastProductId = $productData['entity_id'];

                $productIndex = [$productData['entity_id'] => $productsAttributes[$productData['entity_id']]];
                if (isset($relatedProducts[$productData['entity_id']])) {
                    $childProductsIndex = $this->getChildProductsIndex(
                        $productData['entity_id'],
                        $relatedProducts,
                        $productsAttributes
                    );
                    if (empty($childProductsIndex)) {
                        continue;
                    }
                    $productIndex = $productIndex + $childProductsIndex;
                }

                $index = $this->dataProvider->prepareProductIndex($productIndex, $productData, $storeId);
                
                //custom kharvi headless
                if(!empty($attributes) && $attributes!=''){
                    $custom_data = explode(',', $attributes);
                    
                    $attribute_codes=array();
                    foreach($custom_data as $key => $value){
                        list($key, $code) = explode('__', $value);
                        array_push($attribute_codes, $code);
                    }
                    
                    if($flat_enabled){
                        $attributes_select = implode(',', $attribute_codes);
                        $sql ="select $attributes_select, created_at, price from catalog_product_flat_$storeId where entity_id='".$productData['entity_id']."'";
                        $data = $this->connection->fetchAll($sql);
                        
                        if(isset($data[0])){
                            $product = $data[0];
                            
                            foreach($custom_data as $key => $value){
                                list($key, $code) = explode('__', $value);
                                if(!array_key_exists($key,$index)){
                                    $index[$code] = $product[$code];
                                }
                            }
                            
                            $index['original_price'] = $product['price'];
                        }
                    }else{
                        $product = $this->getLoadProduct($productData['entity_id']);
                        
                        foreach($custom_data as $key => $value){
                            list($key, $code) = explode('__', $value);
                            if(!array_key_exists($key,$index)){
                                $index[$code] = $product[$code];
                            }
                        }
                        
                        $index['original_price'] = $product['price'];
                    }
                    $index['entity_id'] = $productData['entity_id'];
                    
                    $productId = $index['entity_id']; //this is child product id
                    $sql = "select parent_id from catalog_product_relation where child_id='$productId' limit 1";
                    $parentId = $this->connection->fetchOne($sql);
                    
                    //parent_url
                    $index['parent_url'] = '';
                    if(!empty($parentId)){
                        $parent_product = $this->getLoadProduct($parentId);
                        $index['parent_url'] = $parent_product->getUrlKey();
                    }
    
                    #print_r($index);
                }
                //custom kharvi headless
                
                yield $productData['entity_id'] => $index;
            }
            
            $offset++;
            $lastProductId = $offset * $this->batchSize; 
            $products = $this->dataProvider
                ->getSearchableProducts($storeId, $staticFields, $productIds, $lastProductId, $this->batchSize);
        }
    }
    
    //custom kharvi headless
    public function getLoadProduct($id)
    {
        return $this->_productloader->create()->load($id);
    }
    
    /**
     * Get related (child) products ids
     *
     * Load related (child) products ids for composite product type
     *
     * @param array $products
     * @return array
     */
    private function getRelatedProducts($products)
    {
        $relatedProducts = [];
        foreach ($products as $productData) {
            $relatedProducts[$productData['entity_id']] = $this->dataProvider->getProductChildIds(
                $productData['entity_id'],
                $productData['type_id']
            );
        }
        return array_filter($relatedProducts);
    }
}