<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Headless\Model\Config;

class Options implements \Magento\Framework\Option\ArrayInterface
{   
    protected $productAttributeCollectionFactory;

    public function __construct(\Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $productAttributeCollectionFactory)
    {
        $this->productAttributeCollectionFactory = $productAttributeCollectionFactory;
    }

    public function toOptionArray()
    {
        $productAttributes = $this->productAttributeCollectionFactory->create();
        $productAttributes->addFieldToFilter(
            ['is_filterable'],
            [0]
        );
        
        $options = [];
        foreach ($productAttributes as $attribute) {
            if(!in_array($attribute->getAttributeCode(), array('name', 'sku', 'visibility', 'category_ids'))){
                $attribute_key = $attribute->getAttributeId().'__'.$attribute->getAttributeCode();
                $options[] = ['label' => $attribute->getFrontendLabel(), 'value'=>$attribute_key];
            }
        }
        
        return $options;
    }
}