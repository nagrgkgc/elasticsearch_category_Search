<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Headless\Model\Config;

class FilterableOptions implements \Magento\Framework\Option\ArrayInterface
{   
    protected $productAttributeCollectionFactory;

    public function __construct(\Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $productAttributeCollectionFactory)
    {
        $this->productAttributeCollectionFactory = $productAttributeCollectionFactory;
    }

    public function toOptionArray()
    {
        $productAttributes = $this->productAttributeCollectionFactory->create();
        
        $options = [];
        $options[] = ['label' => '-- Select One---', 'value'=>''];
        foreach ($productAttributes as $attribute) {
            if(!in_array($attribute->getAttributeCode(), array('name', 'sku', 'visibility', 'category_ids'))){
                $options[] = ['label' => $attribute->getFrontendLabel(), 'value'=>$attribute->getAttributeCode()];
            }
        }
        
        return $options;
    }
}