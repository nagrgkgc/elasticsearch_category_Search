<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Headless\Helper;

use Magento\Framework\UrlInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $_catalogHelper;
    protected $_storeManager;
    protected $_registry;
    protected $_catalogSearchData;
    protected $_categoryRepository;
    protected $_escaper;
    protected $_urlBuilder;
    protected $_request;
    protected $_scopeConfig;
    protected $_currency;
    
    public $final_url_data = array();
    public $_filtersList = array();
    
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Helper\Data $catalogHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\CatalogSearch\Helper\Data $catalogSearchData,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        \Magento\Framework\Escaper $_escaper,
        UrlInterface $urlBuilder,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $productAttributeCollectionFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Directory\Model\Currency $currency
    ){
        $this->_registry = $registry;
        $this->_catalogHelper = $catalogHelper;
        $this->_storeManager = $storeManager;
        $this->_catalogSearchData = $catalogSearchData;
        $this->_categoryRepository = $categoryRepository;
        $this->_escaper=$_escaper;
        $this->_urlBuilder = $urlBuilder;
        $this->_request = $request;
        $this->productAttributeCollectionFactory = $productAttributeCollectionFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_currency = $currency; 
    }
    
    public function buildActiveUrls($isLayer = false) {
        //get base url of store
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
        
        //base url and base 
        $crumbs[] = array('url' => $baseUrl, 'name' => 'Home', 'ishome' => 1);
        
        //build category url here
        $layerCat = array();
        $_currentCategory = $this->_registry->registry('current_category');//get current category
        
        //get query text
        $queryTxt = $this->_catalogSearchData->getEscapedQueryText();
        
        if ($_currentCategory) {
            $parentId = $_currentCategory->getId();
            if ($_currentCategory->getLevel() == 2) {
                
                $crumbs[] = array('url' => $_currentCategory->getUrl(), 'name' => $_currentCategory->getName(), 'sep' => true);
                
            } elseif ($_currentCategory->getLevel() == 3) {
                
                $categoryId = $_currentCategory->getParentId();
                $category2 = $this->_categoryRepository->get($categoryId, $this->_storeManager->getStore()->getId());
                $crumbs[] = array('url' => $category2->getUrl(), 'name' => $category2->getName(), 'sep' => true);
                $crumbs[] = array('url' => $_currentCategory->getUrl(), 'name' => $_currentCategory->getName(), 'sep' => false);
                
            } elseif ($_currentCategory->getLevel() == 4) {
                
                $categoryId = $_currentCategory->getParentId();
                $category2 = $this->categoryRepository->get($categoryId, $this->_storeManager->getStore()->getId());
                
                $parentId = $category2->getParentId();
                $category2 = $this->categoryRepository->get($parentId, $this->_storeManager->getStore()->getId());
                $crumbs[] = array('url' => $category3->getUrl(), 'name' => $category3->getName(), 'sep' => true);
                $crumbs[] = array('url' => $category2->getUrl(), 'name' => $category2->getName(), 'sep' => true);
                $crumbs[] = array('url' => $_currentCategory->getUrl(), 'name' => $_currentCategory->getName(), 'sep' => true);
                
            }
        } else {
            if (!empty($queryTxt)) {
                if ($queryTxt != '') {
                    $params['q'] = $queryTxt;
                    $url = $this->_urlBuilder->getUrl('*/*/*', array('_use_rewrite' => true, '_query' => $params));
                    $crumbs[] = array('url' => $url, 'name' => $queryTxt, 'label' => 'Search');
                }
            }
        }

        if ($isLayer) {
            return $layerCat;
        }

        return $crumbs;
    }
    
    public function buildBreadCrumbsHtml(){
        $bradcrumbs = $this->buildActiveUrls(false);
        
        $b = 0;
        $backUrl = $this->_storeManager->getStore()->getBaseUrl();
        $homelk = true;
        if (!empty($bradcrumbs) && isset($bradcrumbs[count($bradcrumbs) - 2]['url'])) {
            $backUrl = $bradcrumbs[count($bradcrumbs) - 2]['url'];
            $homelk = false;
        }
        $html = '<div class="custom_breadcrumbs">';
        $html .= '<ul>';
        $label = '';
        $html .= '<li class="back"><a href="' . $backUrl . '" class="';
        if ($backUrl == $this->_storeManager->getStore()->getBaseUrl() || $homelk) {
            $html .= ' homelk';
        }
        $html .= '">' . __('Back') . '</a></li>';
        foreach ($bradcrumbs as $fKey => $fVal) {
            if (isset($fVal['name'])) {

                $fVal['label'] = (isset($fVal['label'])) ? $this->_escaper->escapeHtml($fVal['label']) : "";
                $fVal['name'] = (isset($fVal['name'])) ? $this->_escaper->escapeHtml($fVal['name']) : "";

                $html .= '<li class="category_bc';
                $url = $fVal['url'];
                $clsLast = '';
                $cls = '';
                if ($b >= (count($bradcrumbs) - 1)) {
                    $html .= ' last';
                    $url = '#';
                    $clsLast = ' last';
                }
                $html .= '">';
                if ($b < (count($bradcrumbs)) && isset($fVal['label']) && $fVal['label'] != $label && $b != 0) {
                    $html .= '<span> / </span>';
                } elseif ($b < (count($bradcrumbs)) && $b != 0 && isset($fVal['clabel']) && $fVal['clabel']) {
                    $html .= '<span> / </span>';
                } else {
                    $cls = "same_attr";
                }
                if (isset($fVal['label']) && $label != $fVal['label'])
                    $html .= '<span class="bread_options_name">' . __($fVal['label']) . ' :&nbsp;</span>';
                $html .= '<a href="' . $url . '" title="' . $fVal['name'] . '" class="' . $clsLast . ' ' . $cls;
                if (isset($fVal['ishome']) && $fVal['ishome'])
                    $html .= ' homelk';
                $html .= '">' . __($fVal['name']) . '</a>';
                if (isset($fVal['sep']) && $fVal['sep']) {
                    //
                }
                $html .= '</li>';
                $b++;
                $label = (isset($fVal['label'])) ? $fVal['label'] : '';
            }
        }
        $html .= '</ul>';
        $html .= '</div>';

        return $html;
    }
    
    /* get category by id */
    public function getCategory($categoryId){
        return $this->_categoryRepository->get($categoryId, $this->_storeManager->getStore()->getId());
    }
    
    private function unsetKeyIfHasOnlyOne($uriParams) {
        if (!empty($uriParams) && count($uriParams) > 0) {
            $valueString = '';
            foreach ($uriParams as $key => $value) {
                if (isset($key) && $key != 'q') {
                    if (count($value) == 1) {
                        if (isset($value[0])) {
                            $singleValue = $value[0];
                            if ($key == 'price' && isset($singleValue))
                                $singleValue = str_replace('TO', '-', $singleValue);
                            $uriParams[$key] = $singleValue;
                        }else {
                            $uriParams[$key] = $value;
                        }
                    } else {
                        $filtervalueString='';
                        foreach($value as $filtervalue){
                            $filtervalueString .= $filtervalue.',';
                        }
                        $filtervalueString = rtrim($filtervalueString, ',');
                        $uriParams[$key] = $filtervalueString;
                    }
                }
            }

            return $uriParams;
        }

        return $uriParams;
    }
    
    /* build final url data */
    public function buildFinalFilterUrls($new_allFiletrs, $addLabel) {
        $params = $this->_request->getParams();
        
        //unset some params
        unset($params['id']);
        unset($params['isAjax']);
        
        foreach ($new_allFiletrs as $k4 => $v4) {
            foreach ($v4 as $k5 => $v5) {
                $urlParams = array();
                $urlParams = $v5;
                unset($urlParams['isAjax']);
                if (isset($params['q']) && $params['q'] != '')
                    $urlParams['q'] = $params['q'];

                #unset single key values	
                $urlParams = $this->unsetKeyIfHasOnlyOne($urlParams);
                $url = $this->_urlBuilder->getUrl('*/*/*', array('_use_rewrite' => true, '_query' => $urlParams));

                if ($addLabel) {
                    $v5V = (isset($v5[1])) ? $v5[1] : '';
                    $lbl = '';
                    if (strpos($k4, 'price') == true) {
                        $lbl = 'Price';
                    } elseif (isset($this->_filtersList[$k5])) {
                        $lbl = $this->_filtersList[$k5];
                    }
                    $this->final_url_data[$k4] = array('url' => $url, 'label' => $lbl, 'attr' => $k4, 'key' => $v5V);
                } else {
                    $this->final_url_data[$k5] = $url;
                }
            }
        }
    }
    
    /* get website id */
    public function getWebsiteId(){
        $wid = $this->_storeManager->getStore()->getWebsiteId();
        $widd = '_0_' . $wid;
        
        return $widd;
    }
    
    /* build active filter data */
    public function buildActiveStateUrls($activeFilters = array(), $filtersList) {
        if (isset($_GET['showall']))$activeFilters['showall'] = 1;

        $activeStates = array();
        $filtersBefClean = array();
        $wid = $this->_storeManager->getStore()->getWebsiteId();
        $widd = '_0_' . $wid;
        $_currentCategory = $this->_registry->registry('current_category');
        $activeFilters['cat'] = $this->buildActiveUrls(true);

        $this->_filtersList = $filtersList;
        if (!empty($activeFilters['cat'])) {
            $filtersBefClean['cat'] = $activeFilters['cat'];
        }
        unset($activeFilters['cat']);
        
        foreach ($activeFilters as $actFlK => $actFlV) {
            $attrFilterName = $actFlK;
            if (is_array($actFlV)) {
                foreach ($actFlV as $aFK => $aFV) {
                    $filtersBefClean[$aFV . '_' . $attrFilterName] = $actFlK;
                }
            } else
                $filtersBefClean[$actFlV . '_' . $attrFilterName] = $actFlK;
        }

        if (!empty($filtersBefClean)) {
            $finalActiveStateUrls = array();
            $keyName = '';
            if (!empty($filtersBefClean['cat'])) {
                $activeStates['cat'] = $filtersBefClean['cat'];
            }
            unset($filtersBefClean['cat']);
            
            if ($filtersList) {
                foreach ($filtersBefClean as $afKey => $afVal) {
                    $afts = array();
                    if (!empty($afVal)) {
                        foreach ($filtersBefClean as $actFilterKey => $actFilterVal) {
                            $newAfKey = $actFilterVal;

                            if ($afKey == $actFilterKey) {
                                $keyName = $newAfKey;
                                continue;
                            }
                            $afts[$newAfKey][] = str_replace($widd, '', str_replace('_' . $newAfKey, '', $actFilterKey));
                        }
                    }
                    
                    if(!in_array($keyName, array('dir', 'sort'))){
                        $activeStates[$afKey][$keyName] = $afts;
                    }
                }
            }
        }

        if (count($activeStates) == 1 && isset($activeStates['1_showall']))
            $activeStates = [];
            
        if (!empty($activeStates))
            $this->buildFinalFilterUrls($activeStates, true);

        return $this->final_url_data;
    }
    
    /* get all active url params */
    public function getActiveFilters(){
        $params = $this->_request->getParams();
        
        //unset id
        if(isset($params['id']))unset($params['id']);
        if(isset($params['page']))unset($params['page']);
        if(isset($params['q']))unset($params['q']);
        #if(isset($params['sort']))unset($params['sort']);
        #if(isset($params['dir']))unset($params['dir']);
        
        $filters = array();
        if(!empty($params)){
            foreach($params as $key => $value){
                if(!empty($value) && $value!=''){
                    $list = explode(',', $value);
                    
                    if(count($list)){
                        $filters[$key] = $list;
                    }
                }
            }
        }
        
        return $filters;
    }
    
    public function getCurrentUrl() {
        $param = array();
        $url = $this->_storeManager->getStore()->getCurrentUrl();
        $urlSplit = explode('?', $url);

        $finalBaseUrl = $urlSplit[0];

        if (isset($urlSplit[1]) && (strpos($url, '&q=') !== false || strpos($url, '?q=') !== false)) {
            $queryTxt = $this->_catalogSearchData->getEscapedQueryText();

            $finalBaseUrl = $urlSplit[0] . '?q=' . $queryTxt;
        }

        return $finalBaseUrl;
    }
    
    /* get categories by id */
    public function getChildCategoriesByParent($currentCategoryId){
        $childCategoryObj = $this->_categoryRepository->get($currentCategoryId);
        $childSubcategories = $childCategoryObj->getChildrenCategories();
        
        return $childSubcategories;
    }
    
    public function getFilterableAttributes()
    {
        /* @var \Magento\Catalog\Model\ResourceModel\Product\Attribute\Collection $productAttributes */
        $productAttributes = $this->productAttributeCollectionFactory->create();
        $productAttributes->addFieldToFilter(
            ['is_filterable', 'is_filterable_in_search'],
            [[1, 2], 1]
        );
 
        return $productAttributes;
    }
    
    /* get filterable filters */
    public function getFilterableFilters() {
        $attributes = $this->getFilterableAttributes();

        $attribute_arr = array();
        foreach ($attributes as $attribute) {
            //if ($attribute->usesSource()) {
                $attribute_arr[$attribute->getAttributeCode()]['id'] = $attribute->getAttributeId();
                $attribute_arr[$attribute->getAttributeCode()]['name'] = $attribute->getFrontendLabel();
            //}
        }

        unset($attribute_arr['category']);

        if (count($attribute_arr) > 0) {
            return $attribute_arr;
        }

        return array();
    }
    
    /**
     * custom sorting as per the given order
     * */
    public function customSortingByKey($array = array()) {
        if (empty($array)) {
            return $array;
        }
        $order_key = $this->_scopeConfig->getValue('kharvi_headless/general/size_sorting', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        if(!empty($order_key)){
            $sorted_array = @array_intersect_key(array_flip($order_key), $array);
            return $sorted_array;
        }
        
        return $array;
    }
    
    /* get price range step */
    public function getPriceRangeStep(){
        $step = $this->_scopeConfig->getValue('catalog/layered_navigation/price_range_step', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $intervals = $this->_scopeConfig->getValue('catalog/layered_navigation/price_range_max_intervals', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        
        return array($step, $intervals);
    }
    
    /**
     * custom array key sorting function
     * */
    public function customSorting($array = array()) {
        $numeric = array();
        $remain = array();
        $alpha = array();
        $sorted_sizes = array();
        foreach ($array as $key => $value) {
            if (is_numeric($key) or is_float($key)) {
                $numeric[$key] = $value;
            } else {
                $alpha[$key] = $value;
            }
        }
        
        ksort($numeric); //ksort($remain);// ksort($alpha);
        $alpha_sorted = (array) $this->customSortingByKey($alpha);
        $sorted_array = array_merge($numeric, $alpha_sorted);
        
        return $sorted_array;
    }
    
    /* unpagination links */
    public function unsetPaginationFromLinks($filter, $fValue) {
        $cparam = $this->_request->getParams();

        if (isset($cparam['page']))
            unset($cparam['page']);
        if (isset($cparam['id']))
            unset($cparam['id']);
        if (isset($cparam['isAjax']))
            unset($cparam['isAjax']);

        //remove key if no value found
        if (($key = array_search('', $cparam)) !== false) {
            unset($cparam[$key]);
        }
        
        if (strpos($fValue, '*-') !== false) {
    		$fValue = str_replace('*-', '-', $fValue);
    	}elseif(strpos($fValue, '-*') !== false){
    		$fValue = str_replace('-*', '-', $fValue);
    	}else{
    	    $fValue = $fValue;
    	}
    	
    	$build_url_values = array();
    	if(isset($cparam[$filter]) && $cparam[$filter]!=''){
    	    $existing_filter_value = $cparam[$filter];
    	    $existing_filter_values = explode(',', $existing_filter_value);
    	    
    	    if(count($existing_filter_values)>0){
    	        foreach($existing_filter_values as $key => $value){
	                array_push($build_url_values, $value);
    	        }
    	    }
    	}
    	
    	if(in_array($fValue, $build_url_values)){
            if (($key = array_search($fValue, $build_url_values)) !== false) {
               unset($build_url_values[$key]);
            }
        }else{
            array_unshift($build_url_values, $fValue);
        }
        
        //sort array here
        asort($build_url_values);
        
        unset($cparam[$filter]);
	    $build_url_values_string = implode(',', $build_url_values);
	    if(!empty($build_url_values_string) && $build_url_values_string!=''){
	        $cparam[$filter] = $build_url_values_string;
	    }

        $params = $cparam;//array_merge_recursive($cparam, $params);

        return $params;
    }
    
    public function checkIfFilterExists($filter, $filterValueKey, $filterValue, $params, $activeStateUrlsDecode) {
        if (isset($params['id']))
            unset($params['id']);
        if (isset($params['isAjax']))
            unset($params['isAjax']);
            
        $selectedVal = 0;
        $selectedUrl = '';
        
        if (strpos($filterValueKey, '*-') !== false) {
    		$filterValueKey = str_replace('*-', '-', $filterValueKey);
    	}elseif(strpos($filterValueKey, '-*') !== false){
    		$filterValueKey = str_replace('-*', '-', $filterValueKey);
    	}else{
    	    $filterValueKey = $filterValueKey;
    	}
        
        if (!empty($params) && isset($filter)) {
            if (array_key_exists(trim($filter), $params) && $filterValue!='') {
                $filterValues = explode(',', $filterValue);
                if (isset($filterValue) && isset($activeStateUrlsDecode[$filterValueKey . "_" . $filter]) && count($filterValues)>1 && in_array($filterValueKey, $filterValues)) {
                    if (!empty($activeStateUrlsDecode) && is_array($activeStateUrlsDecode)) {
                        $selectedVal = 1;
                        $selectedUrl = $activeStateUrlsDecode[$filterValueKey . "_" . $filter]['url'];
                        return array($selectedVal, $selectedUrl);
                    }
                } elseif (isset($filterValue) && isset($activeStateUrlsDecode[$filterValueKey . "_" . $filter]) && $filterValue == $filterValueKey) {
                    $selectedVal = 1;
                    $selectedUrl = $activeStateUrlsDecode[$filterValueKey . "_" . $filter]['url'];

                    return array($selectedVal, $selectedUrl);
                }
            }
        }

        return array();
    }
    
    /* pagination url set */
    public function setPaginationFromLinks($page) {
        $params = $this->_request->getParams();

        if (isset($params['id']))
            unset($params['id']);
            
        $params['page'] = $page;

        //remove key if no value found
        if (($key = array_search('', $params)) !== false) {
            unset($params[$key]);
        }

        $url = $this->_urlBuilder->getUrl('*/*/*', array('_use_rewrite' => true, '_query' => $params));
        
        return $url;
    }
    
    /* pagination url set */
    public function setSortableLink($value, $type) {
        $params = $this->_request->getParams();

        if (isset($params['id']))
            unset($params['id']);
            
        if($type == 'sort'){
            $params['sort'] = $value;
        }else{
            $params['dir'] = $value;
        }

        //remove key if no value found
        if (($key = array_search('', $params)) !== false) {
            unset($params[$key]);
        }

        $url = $this->_urlBuilder->getUrl('*/*/*', array('_use_rewrite' => true, '_query' => $params));
        
        return $url;
    }
    
    /* get number of products per page */
    public function getNumberOfProductsPerPage(){
        $perpage = $this->_scopeConfig->getValue('catalog/frontend/grid_per_page', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        
        return $perpage;
    }
    
    /**
     * Get currency symbol for current locale and currency code
     *
     * @return string
     */ 
    public function getCurrentCurrencySymbol()
    {
        return $this->_currency->getCurrencySymbol();
    }
    
    /* get current sort dir */
    public function getCurrentDirection(){
        $dir = $this->_request->getParam('dir');
    	
    	if($dir == 'desc'){
    		$dir = 'asc';
		}elseif(empty($dir) || $dir!=''){
    		$dir = 'desc';
    	}else{
    		$dir = 'desc';
    	}
    	
    	return $dir;
    }
}