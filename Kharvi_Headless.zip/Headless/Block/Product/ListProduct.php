<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Headless\Block\Product;

use Magento\Framework\Data\Helper\PostHelper;
use Magento\Catalog\Model\Layer\Resolver;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Framework\Url\Helper\Data;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Category;

class ListProduct extends \Magento\Catalog\Block\Product\ListProduct
{
    protected $_registry;
    protected $_scopeConfig;
    protected $helperData;
    protected $_catalogSearchData;
    protected $_categoryRepository;
    protected $productAttributeCollectionFactory;
    public $productAttributes;
    public $config;
    
    public function __construct(
    	\Magento\Catalog\Block\Product\Context $context,
        PostHelper $postDataHelper,
        Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository,
        Data $urlHelper,
        array $data = [],
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Kharvi\Headless\Helper\Data $helperData,
        \Magento\CatalogSearch\Helper\Data $catalogSearchData,
        \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $productAttributeCollectionFactory,
        \Magento\Catalog\Model\Config $config
    ){
        $this->_registry = $registry;
        $this->_scopeConfig = $scopeConfig;
        $this->helperData = $helperData;
        $this->_catalogSearchData = $catalogSearchData;
        $this->_categoryRepository = $categoryRepository;
        $this->productAttributeCollectionFactory = $productAttributeCollectionFactory;
        $this->config = $config;
        
        parent::__construct(
        	$context,
	        $postDataHelper,
	        $layerResolver,
	        $categoryRepository,
	        $urlHelper,
	        $data
        );
    }
    
    public function getSortByValue($sort_by, $category, $price_key){
    	if($sort_by == 'position'){
			if($category){
				$categoryId = $category->getId();
				$sort_by = 'position_category_'.$categoryId;
			}else{
				//sort by created date or recent products
				$sort_by = 'entity_id';
			}
		}elseif($sort_by == 'price'){
			$sort_by = $price_key;
		}
		
		return $sort_by;
    }
    
    /* getSortDirQuery */
    private function getSortDirQuery($category, $price_key){
    	$sort_by = $this->getRequest()->getParam('sort');
		if(empty($sort_by) || $sort_by==''){
			/*$sort = array(
		        "entity_id" => array("order" => "desc")
			);*/
			$sort_by='entity_id';
			if($category){
				//$sort_by = $category->getDefaultSortBy();
			}else{
				//$sort_by = $this->_scopeConfig->getValue('catalog/frontend/default_sort_by', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
			}
			
			$sort_by = $this->getSortByValue($sort_by, $category, $price_key);
		}else{
			$sort_by = $this->getSortByValue($sort_by, $category, $price_key);
		}
		
		$dir = $this->getRequest()->getParam('dir');
		if(empty($dir) || $dir==''){
			$dir = 'asc';
		}
		
		$sort = array(
	        $sort_by => array("order" => $dir)
		);
		
		return $sort;
    }
    
    /* getCategoryQuery */
    private function getCategoryQuery($category){
    	$categoryId = $category->getId();
			
		$category_query = array(
			"bool"=>array(
				"must" => [
					[
						"term" => [
							"category_ids" => $categoryId
						]
					]
				]
			)
		);
		
		return $category_query;
    }
    
    /* getCleanedQueryParams */
    private function getCleanedQueryParams(){
    	$params = $this->getRequest()->getParams();
    	
    	//unset not required params
		if (isset($params['page']))unset($params['page']);
        if (isset($params['q']))unset($params['q']);
        if (isset($params['id']))unset($params['id']);
        if (isset($params['dir']))unset($params['dir']);
        if (isset($params['sort']))unset($params['sort']);
        //remove key if no value found
        if (($key = array_search('', $params)) !== false) {
            unset($params[$key]);
        }
        
        return $params;
    }
    
    /* getPriceFilterQuery */
    private function getPriceFilterQuery($ValuefiltersList, $key, $values){
    	$price_filter_data=array();
    	
    	if (array_key_exists($key, $ValuefiltersList)) {
			$key = $ValuefiltersList[$key];
		}
		
		if(count($values)>0){
			foreach($values as $fvkey => $fvvalue){
				$fvvalues = explode('-', $fvvalue);
				$to=''; $from='';
				
				if(isset($fvvalues[0]) && $fvvalues[0]==''){
					$from=0;$to=$fvvalues[1]-1;
				}elseif(isset($fvvalues[1]) && $fvvalues[1]==''){
					$from=$fvvalues[0];$to=100000;
				}else{
					$from=$fvvalues[0];$to=$fvvalues[1]-1;
				}
				
				$match = array(
					"range" => array(
						$key => array("from"=>$from, "to"=>$to)
					)
				);
				array_push($price_filter_data, $match);
			}
		}
		
		return $price_filter_data;
    }
    
    /* getPriceMinMaxJsonStringFilter */
    public function getPriceMinMaxJsonStringFilter($price_key){
    	$price_min_max_json_array = array();
		$aggs_fields = array('min_price' => $price_key);
		foreach($aggs_fields as $key => $field){
			$filter = array(
				"stats" => array(
					"field" => $field
				)
			);
			$price_min_max_json_array['stats'] = $filter;
		}
		$price_min_max_json_string = json_encode($price_min_max_json_array);
		
		return $price_min_max_json_string;
    }
    
    /* getMainQuery */
    private function getMainQuery($queryText){
    	$query_array =	array("query_string" => 
			array(
				"query" => $queryText,
				"default_operator" => "and"
			)
		);
		
		return $query_array;
    }
    
    /* getMainQuery */
    private function getMainQueryWithFilter($queryText, $json_string){
    	$query_filter_array_price = array();
    	
    	$query_filter_array_price["must"] = $this->getMainQuery($queryText);
    	
    	if(!empty($json_string) && $json_string!=''){
    		$filter_array =array ("bool" => 
				array("must" => [
						$json_string
					]
				)
			);
			$query_filter_array_price["filter"] = $filter_array;
    	}
    	$main_query = json_encode($query_filter_array_price);
    	
    	return $main_query;
    }
    
    /* getPriceFilterJsonString */
    private function getPriceFilterJsonString($queryText, $price_filter_data, $json_string){
    	$query_filter_array_data = array();
    	$query_filter_array_data["must"] = $this->getMainQuery($queryText);
    	if(!empty($json_string) && $json_string!=''){
    		$filter_array =array ("bool" => 
				array("must" => [
						$json_string
					],
					"should" => $price_filter_data
				)
			);
			$query_filter_array_data["filter"] = $filter_array;
    	}elseif(!empty($price_filter_data) && $price_filter_data!=''){
    		$filter_array =array ("bool" => 
				array(
					"should" => $price_filter_data
				)
			);
			$query_filter_array_data["filter"] = $filter_array;
    	}
    	$query_filter_array_string_data = json_encode($query_filter_array_data);
    	
    	return $query_filter_array_string_data;
    }
    
    /* getAggregationQuery */
    private function getAggregationQuery($aggs_price){
    	$aggs_fields_mapping = array();
		$aggs_fields = array('Category'=>'category_ids');
		if(!empty($aggs_price) && count($aggs_price)>0){
			$aggs_fields['price'] = $aggs_price;
		}
		$productAttributes = $this->getFilterableAttributes();
		foreach ($productAttributes as $attribute) {
            $code = $attribute->getAttributeCode();
            if(!in_array($code, array('price'))){
            	$aggs_fields[$code.'_value'] = $code.'_value';
            }
        }
		
		foreach($aggs_fields as $key => $field){
			if($key == 'price'){
				$filter = array(
					"range" => $field
				);
			}else{
				$filter = array(
					"terms" => array(
						"field" => $field,
						"order" => array( "_key" => "asc" )
					)
				);
			}
			$aggs_fields_mapping[$key] = $filter;
		}
		
		$aggs_json_string = json_encode($aggs_fields_mapping);
		
		return $aggs_json_string;
    }
    
    /* getPostFilter */
    private function getPostFilter($params, $ValuefiltersList){
    	$ptfilter=array();$aggs_fields_mapping_post=array();
		if(count($params)==1){
			foreach($params as $key => $field){
				if($key=='price'){
					$price_filter = $this->getRequest()->getParam('price');
					$values = explode(',', $price_filter);
					$ptfilter = $this->getPriceFilterQuery($ValuefiltersList, $key, $values);
				}else{
					if (array_key_exists($key, $ValuefiltersList)) {
						$key = $ValuefiltersList[$key];
					}
					$fieldValues = explode(',', $field);
					foreach($fieldValues as $value){
						$pfilter = array("term"=> array($key=> $value));
						array_push($ptfilter, $pfilter);
					}
				}
			}
			
			$aggs_fields_mapping_post = array("bool" => 
				array("should" => $ptfilter	)
			);
		}
		
		if(!empty($aggs_fields_mapping_post) && count($aggs_fields_mapping_post)>0){
        	$post_filter = json_encode($aggs_fields_mapping_post);
        }else{
        	$post_filter='{"match_all": {}}';
        }
        
        return $post_filter;
    }
    
    /**
     * Retrieve loaded category collection
     *
     * @return AbstractCollection
     */
    public function getLoadedProductCollection()
    {
    	//initialize data
        $category = $this->_registry->registry('current_category');//get current category
        $host = $this->_scopeConfig->getValue('catalog/search/elasticsearch6_server_hostname', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $port = $this->_scopeConfig->getValue('catalog/search/elasticsearch6_server_port', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $wid = $this->helperData->getWebsiteId();
        $price_key = 'price'.$wid;
        $page = $this->getRequest()->getParam('page');$json=''; $cat = $array = array();
        if (isset($page)) {	$pageno = $this->getRequest()->getParam('page');} else {$pageno = 1;}
		$no_of_records_per_page = $this->getNumberOfProductsPerPage();
		$offset = ($pageno-1) * $no_of_records_per_page; 
		$queryText = $this->_catalogSearchData->getEscapedQueryText();
		if (empty($queryText) && $queryText==''){	$queryText = "*:*";	}
		
		//get sort dir data / encode sort array
		$sort_query = $this->getSortDirQuery($category, $price_key);
		$sort_string = json_encode($sort_query);
		
		//get category query
		if($category){			
			$category_query = $this->getCategoryQuery($category, $price_key);
			if(!empty($category_query)){
				array_push($array, $category_query);
			}
		}
		
		//get query params
		$params = $this->getCleanedQueryParams();
        
        //fetch all filterable attributes
		$ValuefiltersPrice = array('price' => $price_key);
		$attribute_value_codes = $this->getFilterableAttributesValueCodes();
		$ValuefiltersList = array_merge($ValuefiltersPrice, $attribute_value_codes);
        
        $price_filter_data=array();
		if(isset($params) && count($params)>1){
			//unset id param
			if(isset($params['id']))unset($params['id']);
			
			if(count($params)>0){
				foreach($params as $key => $value){
					if(isset($value) && $value!=''){
						$values = explode(',', $value);
						$matches=array();
						if($key == 'price'){
							$price_filter_data = $this->getPriceFilterQuery($ValuefiltersList, $key, $values);
						}else{
							if (array_key_exists($key, $ValuefiltersList)) {
								$key = $ValuefiltersList[$key];
							}
						
							if(count($values)>0){
								foreach($values as $fvkey => $fvvalue){
									$match = array(
										"term" => [
											$key => $fvvalue
										]
									);
									array_push($matches, $match);
								}
							}
								
							if(count($matches)>0 && !empty($matches)){
								$filter = array(
									"bool"=>array(
										"should" => $matches
									)
								);
								
								array_push($array, $filter);
							}
						}
					}
				}
			}
		}
		
		//add default price filters if price filter does not exists
		if(empty($price_filter_data)){
			$price_filter = array(
				"range" => array(
					$price_key => array("gte"=>0, "lte"=>1000000)
				)
			);
			array_push($price_filter_data, $price_filter);
		}
		
		//add all attribute filters to json string
		$json_string='';
		if(count($array)>0 && !empty($array)){
			$json_string = $array;
		}
		
		/* get min , max price data */
		$price_min_max_json_string = $this->getPriceMinMaxJsonStringFilter($price_key);
		
		//construct query data starts
		$main_query = $this->getMainQueryWithFilter($queryText, $json_string);
    	
    	/* for data query */
    	$query_filter_array_string_data = $this->getPriceFilterJsonString($queryText, $price_filter_data, $json_string);
		
		//call same class for data fetch
		$source = '"'.$price_key.'"';
		$result_price = $this->getElasticSearchMinMaxPriceData($host, $port, 0, 10000, $json_string, $price_key, $queryText, $price_min_max_json_string, $source, $main_query);
		
		//get price ranges
		$aggs_price = $this->priceRange($result_price, $price_key);
		
		//prepare aggregator json
		$aggregations = $this->getAggregationQuery($aggs_price);
		
		//get post filter
		$post_filter = $this->getPostFilter($params, $ValuefiltersList);
		
		//call same class for data fetch
		$source = array("original_price", "parent_url", "entity_id", "name","url_key","sku", "image", $price_key);
		$attributes = $this->_scopeConfig->getValue('kharvi_headless/general/attributes', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		if(!empty($attributes) && $attributes!=''){
            $custom_data = explode(',', $attributes);
            $attribute_codes=array();
            foreach($custom_data as $key => $value){
                list($key, $code) = explode('__', $value);
                array_push($attribute_codes, $code);
            }
            $source = array_unique(array_merge($source, $attribute_codes));
		}
		$source = implode('","', $source);
		$result = $this->getElasticSearchData($host, $port, $offset, $no_of_records_per_page, $json_string, $price_key, $queryText, $aggregations, $source, $query_filter_array_string_data, $sort_string, $post_filter);
		
		return $result;
        //return $this->_getProductCollection();
    }
    
    /* fetch data from elastic */
    private function getElasticSearchData($host, $port, $offset, $no_of_records_per_page, $json_string, $price_key, $queryText, $aggregations, $source, $query_filter_array_string, $sort, $post_filter){

    	$json = shell_exec('curl -X POST \''.$host.':'.$port.'/_search?pretty\' -H \'Content-Type: application/json\' -d\'
		{
			"from" : '.$offset.', "size" : '.$no_of_records_per_page.',
			"query" : {
				"bool": '.$query_filter_array_string.'
			},
			"_source" : ["'.$source.'"],
			"aggs": '.$aggregations.',
			"post_filter" : '.$post_filter.',
			"sort": '.$sort.'
		}\'
		');

        //return $this->_getProductCollection();
		$result = json_decode( $json );
		
		return $result;
    }
    
    /* fetch data from elastic */
    private function getElasticSearchMinMaxPriceData($host, $port, $offset, $no_of_records_per_page, $json_string, $price_key, $queryText, $aggregations, $source, $query_filter_array_string){
    	$json = shell_exec('curl -X POST \''.$host.':'.$port.'/_search?pretty\' -H \'Content-Type: application/json\' -d\'
		{
			"from" : '.$offset.', "size" : '.$no_of_records_per_page.',
			"query" : {
				"bool": '.$query_filter_array_string.'
			},
			"_source" : false,
			"aggs": '.$aggregations.'
		}\'
		');

        //return $this->_getProductCollection();
		$result = json_decode( $json );
		
		return $result;
    }
    
    public function getFilterableAttributesValueCodes(){
    	$ValuefiltersList = array();
    	$productAttributes = $this->getFilterableAttributes();
        foreach ($productAttributes as $attribute) {
            $code = $attribute->getAttributeCode();
            if(!in_array($code, array('price'))){
            	$ValuefiltersList[$code] = $code.'_value';
            }
        }
        
        return $ValuefiltersList;
    }
    
    public function getFilterList(){
    	$ValuefiltersList = array('category_ids' => 'Product Category', 'price' => 'Price');
    	$productAttributes = $this->getFilterableAttributes();
    	foreach ($productAttributes as $attribute) {
            $code = $attribute->getAttributeCode();
            $label = $attribute->getFrontendLabel();
            
            $ValuefiltersList[$code] = $label;
    	}
    	
    	return $ValuefiltersList;
    }
    
    public function getFilterableAttributes(){
    	if($this->productAttributes){echo "fffff";
    		return $this->productAttributes;
    	}else{
    		$productAttributes = $this->productAttributeCollectionFactory->create();
	        $productAttributes->addFieldToFilter(
	            ['is_filterable', 'is_filterable_in_search'],
	            [[1, 2], 1]
	        );
    	}
        
        return $productAttributes;
    }
    
    private function priceRange($result, $price_key){
    	$min_price=$max_price=0;
    	if(!empty($result->aggregations)){
			$aggregations = $result->aggregations;
			if(!empty($aggregations->stats->min))$min_price = $aggregations->stats->min;
			if(!empty($aggregations->stats->max))$max_price = $aggregations->stats->max;
			
			//get price range values
			$pricerange_step_intervals = $this->helperData->getPriceRangeStep();
			
			$step = 100;$interval=10;
			if(isset($pricerange_step_intervals[0]))$step=$pricerange_step_intervals[0];
			if(isset($pricerange_step_intervals[0]))$interval=$pricerange_step_intervals[1];
			
			if($min_price>0 && $max_price>0){
				$ranges = $max_price/$step;
				
				$max = $interval;
				if($ranges < $interval)$max = $ranges;
				
				$lastPrice=0;$final_array=array();
				for($p=1; $p<=$max; $p++){
					$array = array();
					if($p==1){
						//first field
						$array['to'] = $step;
					}elseif($p == $max){
						//last field
						$array['from'] = $lastPrice;
					}else{
						$array = array('from' => $lastPrice, 'to' => $lastPrice+$step);
					}
					
					$lastPrice = $p*$step;
					
					array_push($final_array, $array);
				}
				
				if(!empty($final_array)){
					$ranges = $final_array;
					$price_ranges = array("field" => $price_key, "ranges" => $ranges);
				}
				
				return $price_ranges;
			}
		}
		
		return array();
    }
    
    public function getBreadCrumbsHtml(){
    	return $this->helperData->buildBreadCrumbsHtml();
    }
   
    /* get query text and return */ 
    public function getEscapedQueryText(){
    	return $this->_catalogSearchData->getEscapedQueryText();
    }
    
    /* get current category from registry */
    public function getCurrentCategory(){
    	return $this->_registry->registry('current_category');
    }
    
    /* get category by id */
    public function getCategory($categoryId){
    	return $this->helperData->getCategory($categoryId);
    }
    
    /* build filter data */
    public function buildActiveStateUrls($activeFilters, $filterList){
    	return $this->helperData->buildActiveStateUrls($activeFilters, $filterList);
    }
    
    /* get ative filters list*/
    public function getActiveFilters(){
    	return $this->helperData->getActiveFilters();
    }
    
    /* get current url*/
    public function getCurrentUrl(){
    	return $this->helperData->getCurrentUrl();
    }
    
    /* get categories by id */
    public function getChildCategoriesByParent($currentCategoryId){
    	return $this->helperData->getChildCategoriesByParent($currentCategoryId);
    }
    
    /* get filterable filters */
    public function getFilterableFilters() {
    	return $this->helperData->getFilterableFilters();
    }
    
    /* get filterable filters */
    public function customSorting($array) {
    	return $this->helperData->customSorting($array);
    }
    
    /* unpagination links */
    public function unsetPaginationFromLinks($filter, $fValue) {
    	return $this->helperData->unsetPaginationFromLinks($filter, $fValue);
    }
    
    /* check if filter exists */
    public function checkIfFilterExists($filter, $filterValueKey, $filterValue, $params, $activeStateUrlsDecode) {
    	return $this->helperData->checkIfFilterExists($filter, $filterValueKey, $filterValue, $params, $activeStateUrlsDecode);
    }
    
    /* checking if rule exists */
    public function checkIfFilterExistsInRules($filter, $filterValueKey) {
    	return $this->helperData->checkIfFilterExistsInRules($filter, $filterValueKey);
    }
    
    /* pagination url set */
    public function setPaginationFromLinks($page) {
		return $this->helperData->setPaginationFromLinks($page);
    }
    
    /* get number of products per page */
    public function getNumberOfProductsPerPage(){
    	return $this->helperData->getNumberOfProductsPerPage();
    }
    
    /* get number of products per page */
    public function getAttributeUsedForSortByArray(){
    	return $this->config->getAttributeUsedForSortByArray();
    }
    
    /* get current sort */
    public function getCurrentSort($_key){
    	$sort = $this->getRequest()->getParam('sort');
    	
    	if($sort == $_key){
    		return true;
    	}
    	
    	return false;
    }
    
    /* get current sort dir */
    public function getCurrentDirection(){
    	return $this->helperData->getCurrentDirection();
    }
    
    /* pagination url set */
    public function setSortableLink($value, $type) {
    	return $this->helperData->setSortableLink($value, $type);
    }
    
    /* get website id */
    public function getWebsiteId(){
    	return $wid = $this->helperData->getWebsiteId();
    }
    
    /**
     * Get currency symbol for current locale and currency code
     *
     * @return string
     */ 
    public function getCurrentCurrencySymbol()
    {
        return $this->helperData->getCurrentCurrencySymbol();
    }
    
    /* get product url suffix */
    public function getProductUrlSuffix(){
    	return $this->_scopeConfig->getValue('catalog/seo/product_url_suffix', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    
    /**
     * Add attribute.
     *
     * @param array|string|integer|Element $code
     * @return $this
     */
    public function addAttribute($code)
    {
        //$this->_getProductCollection()->addAttributeToSelect($code);
        return $this;
    }
    
    /**
     * Return identifiers for produced content
     *
     * @return array
     */
    public function getIdentities()
    {
        $identities = [];

        $category = $this->getLayer()->getCurrentCategory();
        if ($category) {
            $identities[] = Product::CACHE_PRODUCT_CATEGORY_TAG . '_' . $category->getId();
        }

        //Check if category page shows only static block (No products)
        if ($category->getData('display_mode') == Category::DM_PAGE) {
            return $identities;
        }

        //foreach ($this->_getProductCollection() as $item) {
            // phpcs:ignore Magento2.Performance.ForeachArrayMerge
            //$identities = array_merge($identities, $item->getIdentities());
        //}

        return $identities;
    }
    
    /**
     * Need use as _prepareLayout - but problem in declaring collection from another block.
     * (was problem with search result)
     *
     * @return $this
     */
    protected function _beforeToHtml()
    {
        //$collection = $this->_getProductCollection();

        //$this->addToolbarBlock($collection);

        //if (!$collection->isLoaded()) {
            //$collection->load();
        //}

        return '';//parent::_beforeToHtml();
    }
}