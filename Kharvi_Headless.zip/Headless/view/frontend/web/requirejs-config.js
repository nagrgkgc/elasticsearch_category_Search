var config = {
    map: {
        '*': {
            kharviheadless_addtocart: 'Kharvi_Headless/js/addtocart'
        }
    }
};